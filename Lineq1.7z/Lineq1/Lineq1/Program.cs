﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linqprogram

{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }
    }
    class Program
    {
        public static List<Employee> empList = new List<Employee>
{
//new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
//new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
//new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987/11/14"),DOJ = DateTime.Parse("2015/4/12"),City = "Pune"},
//new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1990/6/3"),DOJ = DateTime.Parse("2016/2/2"),City = "Pune"},
//new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1991/3/8"),DOJ = DateTime.Parse("2016/2/2"),City = "Mumbai"},
//new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("1998/11/7"),DOJ = DateTime.Parse("2014/8/8"),City = "Chennai"},
//new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("1989/12/2"),DOJ = DateTime.Parse("2015/6/1"),City = "Mumbai"},
//new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("1993/11/11"),DOJ = DateTime.Parse("2014/11/6"),City = "Chennai"},
//new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("1992/8/12"),DOJ = DateTime.Parse("2014/12/3"),City = "Chennai"},
//new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("1991/4/12"),DOJ = DateTime.Parse("2016/1/2"),City = "Pune"},



new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"},




};
       
        public static void DisplayAll()
        {
            var displayallemployee = (from s in empList
                         select s);
            foreach (var s in displayallemployee)
            {
                Console.WriteLine(s.EmployeeID+""+s.FirstName+""+s.LastName+""+s.Title+""+s.DOB+""+s.DOJ+""+s.City);
            }
        }
        public static void Notmumbai()
        {
            var NotMumbailist = (from s in empList where s.City != "Mumbai" select s);
            foreach (var s in NotMumbailist)
            { 
                Console.WriteLine(s.EmployeeID+""+s.FirstName+""+s.LastName+""+s.Title+""+s.DOB+""+s.DOJ+""+s.City);
            }
            
        }
        public static void TitleAssesstemt()
        {
            var TitleAssesstemtlist = (from s in empList where s.Title == "AsstManager" select s);
            foreach (var s in TitleAssesstemtlist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }

        }
        public static void LastName()
        {
            var lname = (from s in empList where s.LastName[0] == 'S' select s);
            foreach (var s in lname)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
         public static void JoinBefore()
         {
             var JoinBeforelist = (from s in empList where s.DOJ <= DateTime.Parse ("1-1-2015") select s);
             foreach (var s in JoinBeforelist)
             {
                 Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
             }
         }
         public static void DOBAfter()
        {
            var DOBAforelist = (from s in empList where s.DOB >= DateTime.Parse("1-1-1990") select s);
            foreach (var s in DOBAforelist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void Desegnation()
        {
            var Desegnationlist = (from s in empList where s.Title == "Consultant"||s.Title == "Associate"select s);
            foreach (var s in Desegnationlist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }

        }
        public static void CountAll()
        {
            var Countall = (from s in empList
                                      select s).Count();
 
            {
                Console.WriteLine("total no.of employees="+Countall);
            }
        }
        public static void Chennai()
        {
            var Chennailist = (from s in empList where s.City == "Chennai" select s).Count();
           // foreach (var s in Chennailist)
            {
                // Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
                Console.WriteLine("total no.of employees in chennai=" +Chennailist);
            }

        }
       /*   public static void MaxId()
          {
            // var MaxId = (from s in empList where EmployeeID select s).Max();
            var MaxId = empList.Max(a => a.EmployeeID);
           // Console.WriteLine("Maximum Salary of the Employee: {0}", MaxId);
            foreach (var s in MaxId)
              {
                  Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);

              }
          }*/
        public static void JoinAfter()
        {
            var JoinAfterlist = (from s in empList where s.DOJ >= DateTime.Parse("1-1-2015") select s).Count();
          // foreach (var s in JoinAfterlist)
            {
               // Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
                Console.WriteLine("total no.of employees join after 1-1-2015=" +JoinAfterlist);
            }
        }
        public static void NotAssociate()
        {
            var NotAssociatelist = (from s in empList where s.Title != "Associate" select s).Count();
          // foreach (var s in NotAssociatelist)
            {
                //Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
                Console.WriteLine("total no.of employees NotAssociate=" + NotAssociatelist);
            }

        }
        public static void ByCity()
        {
            var ByCitylist = (from s in empList where s.City == "Mumbai" select s).Count();
            // foreach (var s in NotAssociatelist)
            {
                //Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
                Console.WriteLine("total no.of employees from Chitys=" + ByCitylist);
            }

        }
        public static void CityTitle()
        {
            var CityTitlelist = (from s in empList where s.City == "Mumbai"||s.Title == "AsstManager" select s).Count();
            // foreach (var s in CityTitlelist)
            {
                //Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
                Console.WriteLine("total no.of employees from Chitys=" + CityTitlelist);
            }

        }
      /*  public static void Youngest()
        {
            var Younglist = (from s in empList where s.DOB select s).Min();
            foreach (var s in Younglist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
                
            }

        }*/


        static void Main(String[] args)
        {


             DisplayAll();
             //Notmumbai();
             TitleAssesstemt();
             LastName();
             JoinBefore();
             DOBAfter();
             Desegnation();
             CountAll();
             Chennai();
             JoinAfter();
           // MaxId();
             NotAssociate();
             ByCity();  
             CityTitle();
           // Youngest();
            Console.ReadKey();



        }
    }
}
